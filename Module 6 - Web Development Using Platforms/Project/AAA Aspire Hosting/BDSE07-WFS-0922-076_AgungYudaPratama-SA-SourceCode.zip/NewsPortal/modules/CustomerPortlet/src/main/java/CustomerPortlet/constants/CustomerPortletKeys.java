package CustomerPortlet.constants;

/**
 * @author Administrator
 */
public class CustomerPortletKeys {

	public static final String CUSTOMER =
		"CustomerPortlet_CustomerPortlet";

}