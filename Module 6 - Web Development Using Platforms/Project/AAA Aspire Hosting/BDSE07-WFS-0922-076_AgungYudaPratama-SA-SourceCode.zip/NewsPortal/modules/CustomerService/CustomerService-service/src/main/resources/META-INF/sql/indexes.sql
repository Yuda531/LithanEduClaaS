create index IX_9C57C79A on ACS_Customer (aaa_groupId);
create index IX_53B740A2 on ACS_Customer (uuid_[$COLUMN_LENGTH:75$]);