const NotFound = () => {
    return (
        <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: "80vh"
        }}>
            <h1 className="text-danger">404 Not Found!!!</h1>
        </div>
    );
}

export default NotFound;
