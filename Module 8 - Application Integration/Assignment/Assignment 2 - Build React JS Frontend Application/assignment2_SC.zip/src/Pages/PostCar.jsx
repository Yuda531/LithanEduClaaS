import CarPost from "../Components/CarPost";

const PostCar = () => {
    return (
        <CarPost />
    );
}

export default PostCar;