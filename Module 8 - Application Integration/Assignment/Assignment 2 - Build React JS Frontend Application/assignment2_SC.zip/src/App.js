import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Components/Header";
import CarDetails from "./Pages/CarDetails";
import Home from "./Pages/Home";
import PostCar from "./Pages/PostCar";
import NotFound from "./Pages/NotFound";


const App = () => {
  return (
    <>
      <Router>
      <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/postCar" element={<PostCar/> } />
          <Route path="/carDetails/:id" element={<CarDetails/> } />
          <Route path='*' element={<NotFound />} /> 
        </Routes>
      </Router>
    </>
  );
};

export default App;
