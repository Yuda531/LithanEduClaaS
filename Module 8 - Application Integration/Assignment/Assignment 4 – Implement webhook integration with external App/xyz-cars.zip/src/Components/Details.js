import React from 'react';
import CarImage from '../img/Nissan-GTR-2021.png';

const Details = ({car}) => {
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <div className="card">
                        <img src={CarImage} className="card-img-top" alt="Car" />
                        <div className="card-body">
                            <h5 className="card-title">Car Details</h5>
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item">
                                    <strong>Brand:</strong> {car.brand}
                                </li>
                                <li className="list-group-item">
                                    <strong>Make:</strong> {car.make}
                                </li>
                                <li className="list-group-item">
                                    <strong>Model:</strong> {car.model}
                                </li>
                                <li className="list-group-item">
                                    <strong>Price:</strong> ${car.price}
                                </li>
                                <li className="list-group-item">
                                    <strong>Registration:</strong> {car.registration}
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Details;