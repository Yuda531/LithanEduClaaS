import { Link } from "react-router-dom";
import { useState } from "react";

const Header = () => {
    const [isNavOpen, setIsNavOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");

    const handleNavToggle = () => {
        setIsNavOpen(!isNavOpen);
    };

    const handleSearchSubmit = (event) => {
        event.preventDefault();
        // Lakukan tindakan yang diperlukan dengan query pencarian
        console.log("Search Query:", searchQuery);
        setSearchQuery("");
    };

    return (
        <>
            <nav
                className="navbar navbar-expand-md bg-white navbar-light shadow p-2"
                style={{ marginBottom: "20px" }}
            >
                <Link to="/" className="ling">
                    <a className="navbar-brand d-flex align-items-center px-4 px-lg-5">
                        <h2 className="m-0 text-primary">
                            <i className="fa fa-car me-3"></i>XYZ Cars
                        </h2>
                    </a>
                </Link>
                <button
                    type="button"
                    className="navbar-toggler me-4"
                    onClick={handleNavToggle}
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div
                    className={`collapse navbar-collapse ${isNavOpen ? "show" : ""
                        } justify-content-center`}
                    id="navbarCollapse"
                >
                    <div className="navbar-nav ms-auto p-4 p-lg-0 me-5">
                        <Link to="/" className="ling">
                            <a className="nav-item nav-link">Home</a>
                        </Link>
                        <Link to="/postCar" className="ling">
                            <a className="nav-item nav-link">Post Car</a>
                        </Link>
                        <Link to="/contactUs" className="ling">
                            <a className="nav-item nav-link">Contact Us</a>
                        </Link>
                    </div>
                </div>
            </nav>
        </>
    );
};

export default Header;
