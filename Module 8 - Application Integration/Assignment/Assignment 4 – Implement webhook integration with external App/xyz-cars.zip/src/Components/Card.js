import Nissan from "../img/Nissan-GTR-2021.png";
import axios from 'axios';
import { baseURL } from "../util/port";
import { useState, useEffect } from "react";

const Cars = () => {
    const [cars, setCars] = useState(null);

    useEffect(() => {
        axios.get(baseURL + "/car/all_cars").then((response) => {
            setCars(response.data);
        });
    }, []);

    if (!cars) return null;

    return (
        <>
            <section className="section-container my-section-padding my-1">
                <div className="section-heading container text-center mb-3">
                    <h1>
                        Featured <span>Cars</span>
                    </h1>
                </div>
                <div className="container mx-auto">
                    <div className="row g-4 card-items-container">
                        {cars.map((value, index) => (
                            <div className="col-md-4">
                                <div className="card rounded-0 shadow">
                                    <div className="card-img-container">
                                        <div
                                            className="card-img"
                                            style={{ backgroundImage: `url(${Nissan})` }}
                                        ></div>
                                        <div className="card-ribbon">
                                            <h6>Featured</h6>
                                        </div>
                                    </div>
                                    <div className="card-body">
                                        <h5 className="card-title fw-semibold">{value.brand}</h5>
                                        <p className="card-text text-secondary m-0 my-2">
                                            <span>{value.make}</span>
                                        </p>
                                        <div className="d-flex text-dark">
                                            <span className="me-3" style={{ fontWeight: 'bold', fontSize: '18px' }}>
                                                {value.model}
                                            </span>
                                        </div>
                                        <h3 className="text-danger my-1 fw-semibold">
                                            <span>Rp.{value.price}</span>
                                            <span className="fs-6 text-secondary"></span>
                                        </h3>
                                        <div className="card-action">
                                            <a
                                                href={"/carDetails/" + value.id}
                                                className="btn btn-outline-danger m-1"
                                            >
                                                View Car Details
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </>
    );
}

export default Cars;