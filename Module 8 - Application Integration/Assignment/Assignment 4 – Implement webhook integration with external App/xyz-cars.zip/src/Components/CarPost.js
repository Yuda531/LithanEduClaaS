import React, { useState } from 'react';
import { baseURL } from "../util/port";
import axios from "axios";
import Swal from 'sweetalert';

const CarPost = () => {
    const [brand, setBrand] = useState('');
    const [make, setMake] = useState('');
    const [model, setModel] = useState('');
    const [price, setPrice] = useState('');
    const [registration, setRegistration] = useState('');
    const [formSubmitted, setFormSubmitted] = useState(false);

    const handleSubmit = (event) => {
        event.preventDefault();
        setFormSubmitted(true);

        if (event.target.checkValidity()) {
            handlePostCar();
        }
    };

    const handlePostCar = () => {
        const postData = {
            brand: brand,
            make: make,
            model: model,
            price: price,
            registration: registration
        };

        axios.post(baseURL + "/car/post_car", postData)
            .then(response => {
                console.log(response.data);
                // Lakukan tindakan lain dengan data yang diterima
                successAlert();
            })
            .catch(error => {
                console.error(error);
                // Handle error jika permintaan POST gagal
            });
    };

    const successAlert = () => {
        Swal({
            title: "Success",
            text: "Car posted successfully",
            icon: "success",
            button: {
                text: "OK",
                className: "btn btn-primary"
            }
        }).then(() => {
            window.location.href = "/";
        });
    };

    return (
        <div className="container shadow-lg p-3 rounded-4">
            <h1 className="text-center mb-4">Post Car</h1>
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <form onSubmit={handleSubmit} noValidate className={formSubmitted ? 'was-validated' : ''}>
                        <div className="mb-3">
                            <label htmlFor="" className="form-label">
                                Car Brand
                            </label>
                            <input
                                type="text"
                                className="form-control"
                                id="brand"
                                placeholder="Enter car Brand"
                                value={brand}
                                onChange={(e) => setBrand(e.target.value)}
                                required
                            />
                            <div className="invalid-feedback">
                                Please provide a car brand.
                            </div>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="" className="form-label">
                                Car Make
                            </label>
                            <input
                                type="text"
                                className="form-control"
                                id="make"
                                placeholder="Enter car Make"
                                value={make}
                                onChange={(e) => setMake(e.target.value)}
                                required
                            />
                            <div className="invalid-feedback">
                                Please provide a car make.
                            </div>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="" className="form-label">
                                Car Model
                            </label>
                            <input
                                type="text"
                                className="form-control"
                                id="model"
                                placeholder="Enter car model"
                                value={model}
                                onChange={(e) => setModel(e.target.value)}
                                required
                            />
                            <div className="invalid-feedback">
                                Please provide a car model.
                            </div>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="" className="form-label">
                                Car Price (Rp.)
                            </label>
                            <input
                                type="text"
                                className="form-control"
                                id="price"
                                placeholder="Enter car price"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                required
                            />
                            <div className="invalid-feedback">
                                Please provide a car price.
                            </div>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="" className="form-label">
                                Registration Date
                            </label>
                            <input
                                type="date"
                                className="form-control"
                                id="registration"
                                value={registration}
                                onChange={(e) => setRegistration(e.target.value)}
                                required
                            />
                            <div className="invalid-feedback">
                                Please provide a registration date.
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default CarPost;
