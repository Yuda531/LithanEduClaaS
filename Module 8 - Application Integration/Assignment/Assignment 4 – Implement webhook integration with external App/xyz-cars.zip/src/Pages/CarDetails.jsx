import Details from "../Components/Details";
import { useParams, useHref } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import { baseURL } from "../util/port";

const CarDetails = () => {
    const { id } = useParams();
    const href = useHref();

    const [cars, setCars] = useState(null);

    useEffect(() => {
        axios
            .get(baseURL + "/car/car_details/" + id)
            .then((response) => {
                setCars(response.data);
            })
            .catch((err) => {
                window.location.href = "/";
            });
    }, []);

    if (!cars) return null;

    return <Details car={cars} />
}

export default CarDetails;