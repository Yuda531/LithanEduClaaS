import Cars from "../Components/Card";

const Home = () => {
    return (
        <Cars />
    )
};

export default Home;
