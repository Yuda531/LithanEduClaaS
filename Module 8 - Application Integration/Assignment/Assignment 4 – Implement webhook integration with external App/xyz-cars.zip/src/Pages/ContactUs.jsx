import { useState } from "react";
import { SendAMessage } from "../Services/Service";

const ContactUs = () => {
    const [message, setMessage] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(message);
        SendAMessage(message);
    };

    return (
        <section className="contact-section">
            <div className="container">
                <h1 className="section-title">Send Us a Message</h1>
                <div className="row">
                    <div className="col-lg-6">
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label htmlFor="message">Message:</label>
                                <textarea
                                    className="form-control"
                                    id="message"
                                    rows="5"
                                    value={message}
                                    placeholder="Write some message here..."
                                    onChange={(e) => setMessage(e.target.value)}
                                    required
                                ></textarea>
                            </div>
                            <button type="submit" className="btn btn-primary mt-3">
                                Send Message
                            </button>
                        </form>
                    </div>
                    <div className="col-lg-6 contact-info">
                        <h2>Contact Information</h2>
                        <ul>
                            <li>Email: xyz@cars.com</li>
                            <li>Phone: 0813-2291-0076</li>
                            <li>Address: 123 Priok Street, Jakarta, Indonesia</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ContactUs;
