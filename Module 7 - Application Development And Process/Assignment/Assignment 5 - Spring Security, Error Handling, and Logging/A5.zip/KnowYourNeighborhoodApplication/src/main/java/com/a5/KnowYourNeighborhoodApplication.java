package com.a5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnowYourNeighborhoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnowYourNeighborhoodApplication.class, args);
	}

}
