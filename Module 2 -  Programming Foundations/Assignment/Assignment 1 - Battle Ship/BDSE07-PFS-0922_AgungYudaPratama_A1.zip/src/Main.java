public class Main {
    public static void main(String[] args) {

        System.out.println("This is Assignment 1 of PFS Module :)");
    }
}