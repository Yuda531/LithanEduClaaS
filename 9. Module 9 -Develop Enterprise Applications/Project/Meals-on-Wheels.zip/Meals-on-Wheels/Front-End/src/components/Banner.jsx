// import React from 'react';
// import { Jumbotron, Container } from 'react-bootstrap';

// const Banner = () => {
//   return (
//     <Jumbotron fluid>

//     </Jumbotron>
//   );
// };

// export default Banner;
import React from 'react';
import { Card, Container } from 'react-bootstrap';

const Banner = () => {
  return (
    
       <Container fluid>
        <img className='col-12' src="https://thumbs.dreamstime.com/z/horizontal-backdrop-border-consisted-fresh-organic-food-banner-template-tasty-eco-wholesome-ripe-vegetables-fruits-142317833.jpg?w=992" alt="" />
      </Container>
  );
};

export default Banner;
