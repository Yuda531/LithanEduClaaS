import PartnerManage from "../../components/Admin/PartnerManage";

const ManagePartner = () => {
    return ( 
        <div>
            <PartnerManage />
        </div>
     );
}
 
export default ManagePartner;