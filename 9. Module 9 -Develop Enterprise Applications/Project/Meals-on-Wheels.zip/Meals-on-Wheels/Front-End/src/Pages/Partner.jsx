import PartnerDash from '../components/PartnerDash';
const Partner = () => {
  return (
    <div>
      <PartnerDash />
    </div>



  );
}

export default Partner;