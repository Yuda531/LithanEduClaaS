import StickyHeader from "../components/Navbar";
import Terms from "../components/terms";

function TermsAndCondition(){
    return(
        <>
        <StickyHeader />
        <Terms />
        </>
    )
}

export default TermsAndCondition;