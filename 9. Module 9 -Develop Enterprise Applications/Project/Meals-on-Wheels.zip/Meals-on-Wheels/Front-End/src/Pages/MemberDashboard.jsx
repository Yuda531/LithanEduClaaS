import HeroMember from "../component/HeroMember";
import MemberContent from "../component/MemberContent";

function MemberDashboard(params) {
  return <MemberContent></MemberContent>;
}
export default MemberDashboard;
