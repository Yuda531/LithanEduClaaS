package com.example.kyn.repository;

import com.example.kyn.model.Donor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonorRepository extends JpaRepository <Donor, Long>{

}
