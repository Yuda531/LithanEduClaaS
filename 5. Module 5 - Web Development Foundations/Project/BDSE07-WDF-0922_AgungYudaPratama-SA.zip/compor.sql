-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: compor
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bulk_email`
--

DROP TABLE IF EXISTS `bulk_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulk_email` (
  `bulk_id` int NOT NULL AUTO_INCREMENT,
  `send_by` int DEFAULT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email_body` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`bulk_id`),
  KEY `send_by` (`send_by`),
  CONSTRAINT `bulk_email_ibfk_1` FOREIGN KEY (`send_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_email`
--

LOCK TABLES `bulk_email` WRITE;
/*!40000 ALTER TABLE `bulk_email` DISABLE KEYS */;
INSERT INTO `bulk_email` VALUES (1,1,'Testing Bulk Email','asdasdwads','2023-03-07 14:12:47'),(2,1,'Testing Bulk Email','Atque enim sit est ','2023-03-07 14:20:25'),(3,1,'Testing Bulk Email','Morning to Afternoon','2023-03-07 14:22:53'),(4,1,'Invitations of Cosplay Event  ','Hayuuu gasskeun ngevent tanggal 19 di BTC','2023-03-07 14:25:30'),(5,1,'Invitations of Cosplay Event  ','To All member please come to the Cosplay Event at Bandung Trade Center in 19 March 2023','2023-03-07 14:47:13');
/*!40000 ALTER TABLE `bulk_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education` (
  `education_id` int NOT NULL AUTO_INCREMENT,
  `user_details_id` int NOT NULL,
  `university` varchar(100) NOT NULL,
  `majored` varchar(100) NOT NULL,
  `ed_start_date` date NOT NULL,
  `ed_end_date` date NOT NULL,
  PRIMARY KEY (`education_id`),
  KEY `education to user_details_idx` (`user_details_id`),
  CONSTRAINT `education to user_details` FOREIGN KEY (`user_details_id`) REFERENCES `user_details` (`user_details_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` VALUES (1,7,'Quod iusto tempore ','Temporibus possimus','1970-09-05','1984-09-26'),(2,8,'Reiciendis rem magna','Aut enim voluptas ar','2011-09-01','2001-10-30'),(3,2,'Possimus aspernatur','Error sequi dolore f','1972-05-29','1972-10-29'),(4,3,'Nemo sunt in delenit','Nulla magnam qui vol','1993-09-13','2022-12-18'),(5,4,'Beatae accusantium e','Dicta sed eu qui cup','1994-05-01','2006-09-26'),(6,5,'Cum earum ducimus n','Qui laboris ut possi','2018-11-16','1975-05-26'),(7,6,'Dolorem vel exercita','Possimus culpa nisi','1978-06-17','2012-12-24'),(8,9,'Pariatur Nihil nemo','Inventore consequatu','1985-03-21','1996-08-15'),(9,10,'Lithan Edu Class','Software Engineering','2023-03-09','2027-03-09');
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience` (
  `experience_id` int NOT NULL AUTO_INCREMENT,
  `user_details_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `ex_start_date` date NOT NULL,
  `ex_end_date` date NOT NULL,
  PRIMARY KEY (`experience_id`),
  KEY `experience to user_details_idx` (`user_details_id`),
  CONSTRAINT `experience to user_details` FOREIGN KEY (`user_details_id`) REFERENCES `user_details` (`user_details_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience`
--

LOCK TABLES `experience` WRITE;
/*!40000 ALTER TABLE `experience` DISABLE KEYS */;
INSERT INTO `experience` VALUES (1,7,'In cupiditate error ','Hays and Castro Plc','2013-02-17','2014-03-25'),(2,8,'Voluptate eius aut d','Mccoy Barrera Associates','1982-09-02','1988-08-03'),(3,2,'Elit ea ipsam fugit','Fuller Livingston Plc','1983-05-28','2014-06-27'),(4,3,'Itaque obcaecati per','Perkins and Joyner Associates','1979-10-14','1970-03-29'),(5,4,'Fugiat odio quidem e','Alston Burch Traders','1989-12-09','1999-06-22'),(6,5,'Cupiditate sed expli','Horton Myers Traders','2000-06-08','2019-03-11'),(7,6,'Aspernatur magni duc','Jordan and Nieves Plc','1999-06-21','1979-07-31'),(8,9,'Neque non similique ','Mckee Reese Inc','2011-08-01','2019-10-03'),(9,10,'Ex nulla sint laudan','Chandler and Albert Traders','1976-07-15','1975-09-11');
/*!40000 ALTER TABLE `experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_details` (
  `user_details_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `city` text,
  `phoneNumber` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_details_id`),
  KEY `user_details to users_idx` (`user_id`),
  CONSTRAINT `user_details to users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES (1,1,'Admin','Admin','Baleendah',NULL),(2,2,'Kadeem','Walters','In accusamus autem adipisci dolor','09216745678'),(3,3,'Teegan','Battle','Hogwarts','0917869123'),(4,4,'Asahi','Teruko','Seattle','09127368129368'),(5,5,'Bangkong ','Zuma','Hongkong','07128781723'),(6,6,'Shana','Livingston','Liverpool',NULL),(7,7,'Agung','Yuda','Baleendah','082671630752'),(8,8,'Agung ','Pratama ','Bandung Selatan','0987966215812'),(9,9,'Asep','Ganteng','Pameungpeuk','0128776809'),(10,10,'Aing','Zoro','Kyoto','01924679712'),(11,11,'Rakha','Javier','Rancamanyar',NULL),(12,12,'Syukur','Sidiq','Katapang',NULL),(13,13,'Ajri','Sonic','Katapang',NULL),(14,14,'Abdul','Rahman','Pacet',NULL),(15,15,'Maradilla','Narinda','Bandung',NULL);
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int DEFAULT '2',
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'adminabc@gmail.com','admin123','2023-03-05'),(2,2,'cixonuxob@mailinator.com','qwe','2023-03-05'),(3,2,'byneja@mailinator.com','qwe','2023-03-05'),(4,2,'rawyse@mailinator.com','asd','2023-03-05'),(5,2,'dekygicer@mailinator.com','qwe','2023-03-05'),(6,2,'buxuly@mailinator.com','qwe','2023-03-05'),(7,2,'yuda@gmail.com','qwerty','2023-03-05'),(8,2,'agung@gmail.com','qwe','2023-03-05'),(9,2,'asepsupyad789@gmail.com','qwe','2023-03-05'),(10,2,'yudaagung70@gmail.com','qwe','2023-03-07'),(11,2,'javiermrakha@gmail.com','asd','2023-03-07'),(12,2,'syukursidiqnuralam@gmail.com','asd','2023-03-07'),(13,2,'ajrisonic62@gmail.com','qwe','2023-03-07'),(14,2,'rahmanshalehudin@gmail.com','qwe','2023-03-07'),(15,2,'indah@gmail.com','qwe','2023-03-07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-09 17:26:39
