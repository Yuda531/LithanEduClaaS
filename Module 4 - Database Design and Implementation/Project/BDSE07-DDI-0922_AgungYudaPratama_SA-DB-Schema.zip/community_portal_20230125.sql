CREATE DATABASE  IF NOT EXISTS `community_portal` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `community_portal`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: community_portal
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrator` (
  `admin_id` int NOT NULL,
  `admin_password` varchar(55) NOT NULL,
  `admin_email` varchar(55) NOT NULL,
  `admin_name` varchar(55) NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `administrator_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator`
--

LOCK TABLES `administrator` WRITE;
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
INSERT INTO `administrator` VALUES (1,'Passadmin1','admin1@example.com','Jonatahn Berg',1),(2,'Passadmin2','admin2@example.com','Clara Fox',2),(3,'Passadmin3','admin3@example.com','Laura Love',3),(4,'Passadmin4','admin4@example.com','Michael Brown',2),(5,'Passadmin5','admin5@example.com','Crish John',1);
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apply`
--

DROP TABLE IF EXISTS `apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apply` (
  `user_id` int NOT NULL,
  `job_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`job_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `apply_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `apply_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apply`
--

LOCK TABLES `apply` WRITE;
/*!40000 ALTER TABLE `apply` DISABLE KEYS */;
INSERT INTO `apply` VALUES (1,1),(4,2),(6,3),(5,4),(3,5),(2,6);
/*!40000 ALTER TABLE `apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulk_email`
--

DROP TABLE IF EXISTS `bulk_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulk_email` (
  `email_id` int NOT NULL,
  `content` varchar(155) NOT NULL,
  `admin_id` int NOT NULL,
  PRIMARY KEY (`email_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `bulk_email_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `administrator` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_email`
--

LOCK TABLES `bulk_email` WRITE;
/*!40000 ALTER TABLE `bulk_email` DISABLE KEYS */;
INSERT INTO `bulk_email` VALUES (1,'We are glad to declare the introduction of our new product ABC. You Can Join Us',1),(2,'We encourage you to join us at a future event so you may discover more about our business.',2),(3,'For the role of Full Stack Developer, we are presently hiring.',3),(4,'Come join us on our community portal to share ideas, discuss, and learn together!',4),(5,'Don\'t miss the opportunity to connect with experts in your field on our community portal!',5),(6,'We are now recruiting for the position of Full Stack Developer.',5),(7,'Come discuss, exchange ideas, and learn with us on our community site!',4),(8,'We invite you to attend one of our upcoming events so you can learn more about our company.',3),(9,'We are happy to announce the launch of our new product ABC. You Can Participate',2),(10,'Don\'t miss out on the opportunity to interact with subject matter experts in your area through our community portal!',1);
/*!40000 ALTER TABLE `bulk_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `job_id` int NOT NULL,
  `job_title` varchar(55) NOT NULL,
  `job_desc` varchar(155) NOT NULL,
  `company_id` int NOT NULL,
  `company_name` varchar(55) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (1,'Software Engineer','Develop and maintain software applications for clients',1,'Acme Inc'),(2,'Administrator','Manage and maintain a company\'s',2,'XYZ Corp'),(3,'IT Project Manager','Plan, execute, and finalize projects according to strict deadlines and within budget',3,'ABC Technologies'),(4,'Data Analyst','Collect, analyze, and interpret large data sets to identify patterns and trends',4,'123 Consulting'),(5,'Cybersecurity','Protect an organization\'s computer systems and networks from attack or unauthorized access',5,'Secure Systems Inc'),(6,'DevOps Engineer','Responsible for the design and implementation of continuous integration, continuous delivery, and infrastructure as code.',6,'TechCo'),(7,'Systems Administrator','Install, configure, and maintain operating systems, servers, and other IT infrastructure.',7,'DataWorks'),(8,'Cloud Architect','Design and implement cloud-based solutions using technologies such as AWS, Azure, or Google Cloud. ',8,'DataWorks'),(9,'Business Analyst','Gather and analyze business requirements to identify areas for improvement and implement solutions.',9,'BizTech Solutions'),(10,'Artificial Intelligence Engineer','Design, develop, and implement artificial intelligence and machine learning models.',10,'AI Innovations');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_location`
--

DROP TABLE IF EXISTS `job_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_location` (
  `location` varchar(55) NOT NULL,
  `job_id` int NOT NULL,
  PRIMARY KEY (`location`,`job_id`),
  KEY `job_id` (`job_id`),
  CONSTRAINT `job_location_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_location`
--

LOCK TABLES `job_location` WRITE;
/*!40000 ALTER TABLE `job_location` DISABLE KEYS */;
INSERT INTO `job_location` VALUES ('Singapore',1),('Tokyo',1),('Chicago',2),('Dubai',3),('Qatar',3),('Indonesia',4),('Brazil',5),('Canada',6),('China',7),('Russia',8),('Italy',9),('Turkey',10);
/*!40000 ALTER TABLE `job_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `make`
--

DROP TABLE IF EXISTS `make`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `make` (
  `user_id` int NOT NULL,
  `thread_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`thread_id`),
  KEY `thread_id` (`thread_id`),
  CONSTRAINT `make_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `make_ibfk_2` FOREIGN KEY (`thread_id`) REFERENCES `thread` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `make`
--

LOCK TABLES `make` WRITE;
/*!40000 ALTER TABLE `make` DISABLE KEYS */;
INSERT INTO `make` VALUES (5,1),(1,2),(3,2),(4,3),(1,4);
/*!40000 ALTER TABLE `make` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `messages_id` int NOT NULL,
  `date_send` varchar(55) NOT NULL,
  `content` varchar(155) NOT NULL,
  `receiver_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`messages_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'26/12/2022','Hi there, Agung Yuda! Thanks for being a valued member of the ABC community',2,1,2),(2,'18/08/2022','Hi Abdul Rahman, Whether your teams work in the same office or you work together from afar.',3,2,3),(3,'11/01/2023','Hello Jallen Green, how can I help you with our new product XYZ?',5,3,5),(4,'03/10/2022','content1',1,4,1),(5,'21/10/2022','content2',4,5,4),(6,'01/11/2022','content3',6,6,6),(7,'23/11/2022','content4',7,7,7);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thread` (
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `tittle` varchar(55) NOT NULL,
  `content` varchar(155) NOT NULL,
  `date_created` varchar(55) NOT NULL,
  PRIMARY KEY (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
INSERT INTO `thread` VALUES (1,5,'Best programming languages for beginners','I am new to programming and am wondering what the best languages are to start with. Any suggestions?','01/01/2023'),(2,1,'Help with MySQL query optimization','I am having trouble optimizing a query in MySQL. Can anyone help?','22/12/2022'),(3,4,'JavaScript vs Python','I am trying to decide between JavaScript and Python for web development. What are the pros and cons of each?','30/12/2022'),(4,1,'How to fix a slow computer','My computer has been running slow recently and I\'m not sure how to fix it. Can anyone provide some tips or suggestions on how to speed it up?','15/01/2023'),(5,2,'Upgrading to Windows 10','I\'m planning on upgrading my work computer to Windows 10. Has anyone done this before and can provide some guidance?','12/01/2023'),(6,10,'title 1','Since I\'m new to programming, I\'m unsure of the best languages to learn first. Any recommendations?','01/12/2022'),(7,9,'title 2','For web programming, I\'m stuck between JavaScript and Python. What are each\'s benefits and drawbacks?','10/12/2022'),(8,8,'title 3','For web programming, I\'m stuck between JavaScript and Python. What are each\'s benefits and drawbacks?','20/12/2022'),(9,7,'title 4','My computer has been running slow recently and I\'m not sure how to fix it. Can anyone provide some tips or suggestions on how to speed it up?','30/12/2022'),(10,6,'title 5','My work computer will soon be upgraded to Windows 10. Can anyone who has done this before offer some advice?','07/01/2023');
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_email` varchar(55) NOT NULL,
  `user_name` varchar(55) NOT NULL,
  `location` varchar(55) NOT NULL,
  `user_password` varchar(55) NOT NULL,
  `date_register` varchar(55) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'user1@example.com','Richard Smith','Illinois','12345','03/12/2022'),(2,'user2@example.com','Agung Yuda','Yokohama','qwerty123','21/10/2022'),(3,'user3@example.com','Abdul Rahman','Bandung','abc123','01/02/2022'),(4,'user4@example.com','Michael Davis','New York','Mypass','07/01/2023'),(5,'user5@example.com','Jalen Green','Ohio','Pass321','05/01/2023'),(6,'user6@example.com','User1','New York','password123','01/01/2022'),(7,'user7@example.com','User2','Los Angeles','letmein','01/12/2022'),(8,'user8@example.com','User3','Houston','qwertop','08/07/2022'),(9,'user9@example.com','User4','Moscow','securepassword','11/12/2022'),(10,'user10@example.com','User5','London','hahihohe','05/01/2023');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_education`
--

DROP TABLE IF EXISTS `user_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_education` (
  `education` varchar(55) NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`education`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_education_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_education`
--

LOCK TABLES `user_education` WRITE;
/*!40000 ALTER TABLE `user_education` DISABLE KEYS */;
INSERT INTO `user_education` VALUES ('Bachelor\'s',1),('Master’s, ',1),('Master’s, ',2),('Ph.D',3),('High School',4),('Bachelor\'s',5),('Master’s, ',5),('High School',6),('High School',7),('Bachelor\'s',8),('Master’s, ',9),('Master’s, ',10);
/*!40000 ALTER TABLE `user_education` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-25 16:20:27
